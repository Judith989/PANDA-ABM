Fictional parking environment near downtown Laramie. Not an existing facility.
Extract this ZIP. In PANDA choose Import a 3D environment, select environment.json and synthetic_pavement.glb, then Validate and preview. Confirm the alignment before simulating.
The 1,106-space local geometry, restrictions and driving network match the synthetic transfer experiment; only its geographic anchor and descriptive metadata differ.
